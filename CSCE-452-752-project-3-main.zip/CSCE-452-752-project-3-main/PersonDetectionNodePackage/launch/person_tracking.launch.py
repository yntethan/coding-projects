import launch
import launch.actions
import launch.substitutions
import launch_ros.actions

def generate_launch_description():
    return launch.LaunchDescription([
        launch.actions.DeclareLaunchArgument('bag_in', default_value='input.bag', description='Input bag file'),
        launch.actions.DeclareLaunchArgument('bag_out', default_value='output.bag', description='Output bag file'),
        
        launch_ros.actions.Node(
            package='your_package_name',  # Replace with your package name
            executable='lidar_processor_node.py',  # Node 1 executable
            name='lidar_processor',
        ),
        
        launch_ros.actions.Node(
            package='your_package_name',  # Replace with your package name
            executable='person_counter_node.py',  # Node 2 executable
            name='person_counter',
        ),
        
        # Add nodes for rosbag play and record with appropriate arguments
        # ...

        launch.actions.LogInfo(
            condition=launch.conditions.IfCondition(launch.substitutions.LaunchConfiguration('rosbag_play_complete')),
            value=["All nodes terminated after playing bag file."],
        )
    ])
