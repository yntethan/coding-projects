import rclpy
from rclpy.node import Node
from sensor_msgs.msg import PointCloud
from example_interfaces.msg import Int64

class PersonCounterNode(Node):
    def __init__(self):
        super().__init__('person_counter_node')
        self.person_locations_subscription = self.create_subscription(
            PointCloud,
            '/person_locations',  # Topic where person locations are published
            self.count_people,
            10)
        self.person_count_publisher = self.create_publisher(
            Int64,
            '/person_count',
            10)
        self.unique_people = set()
    
    def count_people(self, msg):
        # Process the PointCloud message to count unique people
        # You can use the data in msg.points to track people
        
        # Calculate the count of unique people
        unique_count = len(self.unique_people)
        
        # Publish the count as an Int64 message
        person_count_msg = Int64()
        person_count_msg.data = unique_count
        self.person_count_publisher.publish(person_count_msg)

def main(args=None):
    rclpy.init(args=args)
    node = PersonCounterNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
