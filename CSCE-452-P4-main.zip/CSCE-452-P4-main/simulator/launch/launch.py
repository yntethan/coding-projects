from launch import LaunchDescription
from launch.actions import (
    DeclareLaunchArgument,
    ExecuteProcess,
    RegisterEventHandler,
    EmitEvent,
)
from launch_ros.actions import *
from launch.substitutions import LaunchConfiguration
from launch.event_handlers import *
from launch.events import *
import yaml


def generate_launch_description():
    # create node that handles simulation
    sim = Node(package="simulator", executable="simulation", name="SimulationControl")

    # create node that takes in and sets up velocity inputs
    vel = Node(package="simulator", executable="velocity", name="VelocityTransform")

    # create node that controls robot movement
    nav = Node(package="simulator", executable="navigation", name="NavControl")

    file_name = r"/home/btallin/humble/p4_ws/src/simulator/config/normal.robot"  # DETERMINES ROBOT DESCRIPTION USED

    # load urdf info from specified .robot yaml file
    robot = load_disc_robot(file_name)
    robot_desc = robot["urdf"]

    # create robot state publisher to update static states info and robot xml (urdf) data to whole program for rviz sim
    robot_state_pub = Node(
        package="robot_state_publisher",
        executable="robot_state_publisher",
        name="robot_state_publisher",
        output="screen",
        parameters=[{"robot_description": robot_desc}],
    )

    # make passed in arguments accessible
    out_name = LaunchConfiguration("bag_out")

    # declare arguments
    bag_out = DeclareLaunchArgument(  # the name of the bag to post to
       "bag_out", default_value="c_out/testx-out"
    )

    # Actions to execute
    rec = ExecuteProcess(cmd=["ros2", "bag", "record", "-a", "-o", out_name])

    #return LaunchDescription([sim, vel, nav, robot_state_pub])
    return LaunchDescription([sim, vel, nav, robot_state_pub, bag_out, rec])


# load robot yaml description specified in given file
def load_disc_robot(file_name):
    with open(file_name) as f:
        robot = yaml.safe_load(f)
    robot["urdf"] = disc_robot_urdf(robot)
    return robot


# create the urdf used to generate 3D robot model
def disc_robot_urdf(robot):
    radius = robot["body"]["radius"]
    height = robot["body"]["height"]

    return f"""<?xml version="1.0"?>
                <robot name="disc">
                    <material name="light_blue">
                        <color rgba="0.5 0.5 1 1"/>
                    </material>
                    <material name="dark_blue">
                        <color rgba="0.1 0.1 1 1"/>
                    </material>
                    <material name="dark_red">
                        <color rgba="1 0.1 0.1 1"/>
                    </material>
                    <link name="base_link">
                        <visual>
                            <geometry>
                                <cylinder length="{height}" radius="{radius}"/>
                            </geometry>
                            <material name="light_blue"/>
                        </visual>
                    </link>
                    <link name="heading_box">
                        <visual>
                            <geometry>
                                <box size="{0.9*radius} {0.2*radius} {1.2*height}"/>
                            </geometry>
                            <material name="dark_blue"/>
                        </visual>
                    </link>
                    <link name="laser" />
                    <joint name="base_to_heading_box" type="fixed">
                        <parent link="base_link"/>
                        <child link="heading_box"/>
                        <origin xyz='{0.45*radius} 0.0 0.0'/>
                    </joint>
                    <joint name="base_to_laser" type="fixed">
                        <parent link="base_link"/>
                        <child link="laser"/>
                        <origin xyz="{0.5*radius} 0.0 0.0"/>
                    </joint>
                </robot>
                """
