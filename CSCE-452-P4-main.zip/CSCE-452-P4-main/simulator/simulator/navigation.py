# Authors: Ben Allin and Ethan Yu
import rclpy
from rclpy.node import Node

from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist

import numpy as np


# Class that will handle navigating the robot to the end of a corridor
class NavControl(Node):
    # constructor
    def __init__(self):
        # Creates Node that will control robot's movement
        super().__init__("nav_control")

        # Hyperparameters:
        # max movement
        self.max_distance = 0.5  # max distance robot can move in meters
        self.max_angle = 1.5  # max angle robot can move in radians
        self.delta_t = 1  # in seconds (technically unnessecary in our case)

        # movement control
        self.forward_angle = 0.35 # range of degrees considered in forward direction (in radians)
        self.forward_distance = 0.5 # min distance before robot starts to turn only
        self.slow_rate = 2.0 # amount robot slows down when approaching obstacles
        self.turn_rate = 0.6 # rate at which robot turns


        # Declare subscription to '/scan' reads in sensor readings
        self.lidar = self.create_subscription(LaserScan, "/scan", self.generate_command, 10)

        # Declare publisher to '/cmd_vel with Twist type to publish linear/angular velocities
        self.command_velocity = self.create_publisher(Twist, "/cmd_vel", 10)


    # generates next point for robot to move to along path and finds velocities for this point
    def generate_command(self, input_msg):
        # point robot will move to in next second (in robot frame)
        distance = 0.0
        theta = 0.0

        # filter data, build direction lists
        forward_scans = []
        left_scans = []
        right_scans = []
        for i in range(len(input_msg.ranges)):
            angle = input_msg.angle_min + i * input_msg.angle_increment

            # make sure data is clean
            if input_msg.ranges[i] == float("inf") or np.isnan(input_msg.ranges[i]):
                continue

            # build direction based scans
            if angle > self.forward_angle: #pos
                left_scans.append(input_msg.ranges[i])
            elif angle < (self.forward_angle*-1) : #neg
                right_scans.append(input_msg.ranges[i])
            else:
                forward_scans.append(input_msg.ranges[i])


        # calculate best point based on directional range lists
        # Assumptions: only one path to follow and scan includes data to the side

        # see if robot can move forward still
        min_forward = np.min(forward_scans)
        if min_forward > self.forward_distance:
            # keep moving forward
            distance = min(self.max_distance, min_forward/self.slow_rate)


        # turn based on the left/right scans
        left_avg = np.average(left_scans)
        right_avg = np.average(right_scans)
        theta = (left_avg-right_avg) * self.turn_rate   

        # make sure theta is not too large (for reasonable movement)
        if theta > self.max_angle:
            theta = self.max_angle
        if theta < -1*self.max_angle:
            theta = -1*self.max_angle


        # create twist message with given point
        command = Twist()
        command.linear.x = distance / self.delta_t # meters/second
        command.angular.z = theta / self.delta_t  # radians/second

        # publish new velocity command
        self.command_velocity.publish(command)


def main(args=None):
    # Initialization
    rclpy.init(args=args)

    # Create node
    nav_control = NavControl()

    # "spins" node so it waits for callbacks
    rclpy.spin(nav_control)

    # Destroy node
    nav_control.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
