import rclpy
from rclpy.node import Node
import yaml
from time import sleep

from std_msgs.msg import Float64
from geometry_msgs.msg import TransformStamped, Point32
from nav_msgs.msg import OccupancyGrid
from sensor_msgs.msg import LaserScan, PointCloud
from tf2_ros import TransformBroadcaster

from math import cos, sin, sqrt, pow
import numpy as np



# Simple class to represent a edge segment
class Edge:
    def __init__(self, x1, y1, x2, y2, direction):
        # points of edge (for collision detection)
        self.x1 = x1
        self.y1 = y1

        self.x2 = x2
        self.y2 = y2

        # direction edge is facing
        self.direction = direction


# Class that will handle simulating the robots actions/states
class SimulationControl(Node):
    # constructor
    def __init__(self):
        # Creates Node that will generate simulation info
        super().__init__("simulation_control")


        # -------------------------------- CREATE MAP FROM DESIGNATED WORLD FILE --------------------------------------
        filename_w = r"/home/btallin/humble/p4_ws/src/simulator/config/cave.world"  # DETERMINES WORLD DESCRIPTION USED
        
        # open/load world file data
        self.world = None
        with open(filename_w) as f:
            self.world = yaml.safe_load(f)

        # create array of strings to represent map from world file
        self.str_map = self.world["map"].splitlines()

        # create occupancy grid
        self.occupancy_grid = OccupancyGrid()

        # update occupancy grid parameters
        self.occupancy_grid.header.frame_id = "world"
        self.occupancy_grid.info.resolution = self.world["resolution"]
        self.occupancy_grid.info.height = len(self.str_map)
        self.occupancy_grid.info.width = len(self.str_map[0])

        # build occupancy grid for map, loop through map rows starting at bottom
        r = len(self.str_map) - 1
        while r > -1:
            
            # for each column add an element to occupancy grid array
            for c in range(len(self.str_map[0])):
                # 100 is for an obstacle (#), 0 for free space (.), else a -1 for unknown
                add = -1
                if (self.str_map[r][c] == '#'):
                    add = 100
                elif (self.str_map[r][c] == '.'):
                    add = 0
                
                self.occupancy_grid.data.append(add)

            r-=1

        # publish occupancy grid to map channel for rviz
        self.grid_pub = self.create_publisher(OccupancyGrid, "/map", 10)
        self.grid_pub.publish(self.occupancy_grid)

        # create map edges for collision detection
        self.edge_list = self.generate_edges()


        # ------------------------------ SPAWN ROBOT INTO MAP, SETUP SIMULATION --------------------------------------------
        filename_r = r"/home/btallin/humble/p4_ws/src/simulator/config/normal.robot"  # DETERMINES ROBOT DESCRIPTION USED
        # gathers and stores robot information
        self.robot = self.load_disc_robot(filename_r)


        # simulation/velocity hyperparameters
        self.UPDATE_FREQ = 60  # determines how frequently robots position is updated per second
        self.error_freq = self.robot["wheels"]["error_update_rate"]  # determines how frequently velocity errors are changed
        self.left_error_var = self.robot["wheels"]["error_variance_left"] # left velocity error variance
        self.right_error_var = self.robot["wheels"]["error_variance_right"] # right velocity error variance

        # lidar hyperparameters
        self.lidar_freq = self.robot["laser"]["rate"]
        self.lidar_count = self.robot["laser"]["count"]
        self.lidar_range_max = self.robot["laser"]["range_max"]
        self.lidar_range_min = self.robot["laser"]["range_min"]
        self.lidar_angle_min = self.robot["laser"]["angle_min"]
        self.lidar_angle_max = self.robot["laser"]["angle_max"]
        self.lidar_err_var = self.robot["laser"]["error_variance"]
        self.lidar_fail_prob = self.robot["laser"]["fail_probability"]

        self.lock = False # locks robots position for lidar scan
        self.move_calls = 1.0 # keeps track of time robot movement is locked for

        # robot dimensions
        self.l_dis = self.robot["wheels"]["distance"]  # distance between robot wheels
        self.robot_radius = self.robot["body"]["radius"]

        # robots inital position (from world file)
        init_pose = self.world["initial_pose"]
        self.x = init_pose[0]
        self.y = init_pose[1]
        self.theta = init_pose[2]

        # robots wheel velocity
        self.left_velocity = 0.0
        self.right_velocity = 0.0

        # robot wheel error
        self.left_error = 1.0
        self.right_error = 1.0

        # initialize world to base transform
        self.world_tf_broadcaster = TransformBroadcaster(self)

        # Declare subscription to vl and vr topics, will determine left and right wheel velocities
        self.left_sub = self.create_subscription(Float64, "/vl", self.move_left, 25)
        self.right_sub = self.create_subscription(Float64, "/vr", self.move_right, 25)

        # Declare lidar scan publisher for simulated lidar sensor results
        self.lidar_pub = self.create_publisher(LaserScan, "/scan", 10)

        # declare lidar scan for rviz
        self.lidar_rviz_pub = self.create_publisher(PointCloud, "/rviz_scan", 10)

        # setup timer to regularly move robot
        self.move_timer = self.create_timer(1 / self.UPDATE_FREQ, self.move)

        # Setup timer to stop robot movement
        self.stop_timer = self.create_timer(1, self.stop)  # (every 1 second)

        # Setup timer to update errors
        self.error_timer = self.create_timer(self.error_freq, self.error)

        # setup timer to regularly update lidar
        self.lidar_timer = self.create_timer(self.lidar_freq, self.lidar_scan)



    # determine if robot is in collision with an obstacle when its center is at (x, y) 
    def collision(self, x, y):
        # helpers
        r = self.robot_radius
        length = self.world["resolution"]
        collision = False

        # loop through edges
        for e in range(len(self.edge_list)):
            edge = self.edge_list[e]

            # check if robot center is within extended edge
            if edge.direction == "up":
                if x > edge.x1 and x < edge.x2 and y < (edge.y1+r) and y > (edge.y2+r-length):
                    collision =True

            elif edge.direction == "down":
                if x > edge.x1 and x < edge.x2 and y > (edge.y1-r) and y < (edge.y2-r+length):
                    collision =True

            elif edge.direction == "left":
                if y > edge.y1 and y < edge.y2 and x > (edge.x1-r) and x < (edge.x2-r+length):
                    collision =True

            elif edge.direction == "right":
                if y > edge.y1 and y < edge.y2 and x < (edge.x1+r) and x > (edge.x2+r-length):
                    collision =True

            # check corners using distances
            distance1 = sqrt(pow((x - edge.x1), 2) + pow((y - edge.y1), 2))
            distance2 = sqrt(pow((x - edge.x2), 2) + pow((y - edge.y2), 2))
            if distance1 < r or distance2 < r:
                collision = True

        return collision
    

    # publish new lidar scan every timer loop
    def lidar_scan(self):
        # lock current position so robots future movements doesnt effect current readings
        curr_x = self.x
        curr_y = self.y
        curr_theta = self.theta
        self.lock = True


        # Setup a lidar sensor with a specific configuration
        lidar_range = self.lidar_range_max  # lidar range in meters
        num_readings = self.lidar_count  # Number of lidar readings
        scan_time = self.lidar_freq  # Time between scans in seconds

        # Create a LaserScan message
        scan_msg = LaserScan()
        scan_msg.header.frame_id = "laser"
        scan_msg.angle_min = self.lidar_angle_min  # Minimum angle of the scan (radians)
        scan_msg.angle_max = self.lidar_angle_max  # Maximum angle of the scan (radians)
        scan_msg.angle_increment = (scan_msg.angle_max - scan_msg.angle_min) / num_readings
        scan_msg.time_increment = scan_time / num_readings
        scan_msg.range_min = self.lidar_range_min  # Minimum range value (meters)
        scan_msg.range_max = lidar_range  # Maximum range value (meters)


        # Simulate lidar data by finding the distance to the nearest obstacle in each direction
        for i in range(num_readings):
            angle = scan_msg.angle_min + i * scan_msg.angle_increment

            # calculate lidar sensor center (base_link to laser)
            start_x = curr_x + 0.5*self.robot_radius*cos(curr_theta)
            start_y = curr_y + 0.5*self.robot_radius*sin(curr_theta)

            # Calculate position of lidar beam endpoint
            end_x = start_x + lidar_range * cos(curr_theta + angle)
            end_y = start_y + lidar_range * sin(curr_theta + angle)

            # Check for collision with obstacles and find the distance
            distance = self.find_nearest_obstacle(start_x, start_y, end_x, end_y)

            # add error to distance
            variance = np.random.default_rng()
            distance = distance + variance.normal(0, self.lidar_err_var)

            # simulate fail property
            if np.random.random() < self.lidar_fail_prob:
                distance = np.NaN

            # Update lidar scan message
            scan_msg.ranges.append(distance)

        # Publish the lidar scan message
        self.lidar_pub.publish(scan_msg)
        self.lidar_rviz_pub.publish(self.laserscan_to_pointcloud(scan_msg))

        # wait for rviz to publish, restart movement
        sleep(0.03)
        self.lock = False


    # Function to find the distance to the nearest obstacle in a given direction
    def find_nearest_obstacle(self, start_x, start_y, end_x, end_y):

        min_distance = float('inf')

        for edge in self.edge_list:
            # Check for intersection between lidar beam and obstacle edge
            intersection = self.line_intersection(start_x, start_y, end_x, end_y, edge.x1, edge.y1, edge.x2, edge.y2)

            # update distance if it is less than previous distances
            if not intersection == None:
                distance = sqrt((start_x - intersection[0])**2 + (start_y - intersection[1])**2)

                if distance < min_distance:
                    min_distance = distance

        # check to make sure obstacles arent to close (shouldnt happen with collisions)
        if min_distance < self.lidar_range_min:
            min_distance = float('inf')

        return min_distance

    # Function to find the intersection point of two lines
    def line_intersection(self, x1, y1, x2, y2, x3, y3, x4, y4):
        # Calculate the determinant of the coefficient matrix
        det = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)

        # If the determinant is zero, the lines are parallel
        if det == 0:
            return None

        # Calculate the intersection point
        px = ((x1 * y2 - y1 * x2) * (x3 - x4) - (x1 - x2) * (x3 * y4 - y3 * x4)) / det
        py = ((x1 * y2 - y1 * x2) * (y3 - y4) - (y1 - y2) * (x3 * y4 - y3 * x4)) / det

        # Check if the intersection point is within the line segments
        err = 0.01 # amount point has to be outside of bounds to be removed, avoids removing horizontal/vertical (pretty much all) lines intersections
        if (px < min(x1, x2) and abs(px - min(x1, x2)) > err   or   px > max(x1, x2) and abs(px - max(x1, x2)) > err  or 
            py < min(y1, y2) and abs(py - min(y1, y2)) > err   or   py > max(y1, y2) and abs(py - max(y1, y2)) > err  or
            px < min(x3, x4) and abs(px - min(x3, x4)) > err   or   px > max(x3, x4) and abs(px - max(x3, x4)) > err  or
            py < min(y3, y4) and abs(py - min(y3, y4)) > err   or   py > max(y3, y4) and abs(py - max(y4, y3)) > err):
            return None

        return px, py

    # convert Laserscan data to pointcloud data
    def laserscan_to_pointcloud(self, scan):
        return PointCloud(header=scan.header, points = [ Point32(x=scan.ranges[i]*cos(scan.angle_min+i*scan.angle_increment), y=scan.ranges[i]*sin(scan.angle_min+i*scan.angle_increment), z=0.0) for i in range(len(scan.ranges)) ])



    # moves the robot based on current wheel velocities, elapsed time based on UPDATE_FREQ hyperparameter
    def move(self):
        # keep robot still while lidar scan is running, track time with no movement
        if self.lock:
            self.move_calls+=1.0
            return
        
        # calculate actual velocity using error values
        vl = self.left_velocity * self.left_error
        vr = self.right_velocity * self.right_error

        # needed helper values
        delta_t = self.move_calls * (1 / self.UPDATE_FREQ)  # change in time
        w = (vr - vl) / self.l_dis  # angular velocity

        # potential new points
        x_new = self.x
        y_new = self.y
        theta_new = self.theta

        # check for special cases
        if vl == -vr:  # robot rotates in place
            theta_new += delta_t * w

        elif vl == vr:  # robot moves in straight line
            x_new += vl * delta_t * cos(self.theta)
            y_new += vl * delta_t * sin(self.theta)

        else:  # robot moves arround ICC

            # calculate ICC location
            radius = (self.l_dis / 2) * ( (vr + vl) / (vr - vl) )  # radius from robot center to ICC

            ICC_loc = [self.x - radius * sin(self.theta), self.y + radius * cos(self.theta)]


            # update position with lecture 4 formula
            x_new = (
                (self.x - ICC_loc[0]) * cos(w * delta_t)
                - (self.y - ICC_loc[1]) * sin(w * delta_t)
                + ICC_loc[0]
            )
            y_new = (
                (self.x - ICC_loc[0]) * sin(w * delta_t)
                + (self.y - ICC_loc[1]) * cos(w * delta_t)
                + ICC_loc[1]
            )
            theta_new += w * delta_t

        # check if new points collide with an obstacle
        if not self.collision(x_new, y_new):
            self.x = x_new
            self.y = y_new
            self.theta = theta_new

        # after new position calculated, update transform
        self.world_to_base_broadcast()
        self.move_calls = 1.0 # reset time between movements


    # updates the left wheel based on current velocities
    def move_left(self, vl_msg):
        self.left_velocity = vl_msg.data

        # reset stop timer since new input was received
        self.stop_timer.reset()

    # updates the right wheel based on current velocities
    def move_right(self, vr_msg):
        self.right_velocity = vr_msg.data

        # reset stop timer since new input was received
        self.stop_timer.reset()


    # use gaussian (normal) distribution to create random velocity error regularly based on frequency specified in .robot file
    def error(self):
        # create random number generater
        left_ran = np.random.default_rng()
        right_ran = np.random.default_rng()

        # sample from normal distribution with mean of 1 and std_dev specified  in .robot file
        self.left_error = left_ran.normal(1, self.left_error_var)
        self.right_error = right_ran.normal(1, self.right_error_var)


    # stops robot movement
    def stop(self):
        self.left_velocity = 0.0
        self.right_velocity = 0.0


    # updates world to baselink transform, broadcasts to tf channel for rviz display
    def world_to_base_broadcast(self):
        # create transform object
        t = TransformStamped()

        # Set meta data of transform
        t.header.stamp = self.get_clock().now().to_msg()
        t.header.frame_id = "world"
        t.child_frame_id = "base_link"

        # since base frame is related to world frame directly by the robots current position,
        # use the robots current position for the transform

        # Get robots current world coordinates
        t.transform.translation.x = self.x
        t.transform.translation.y = self.y
        t.transform.translation.z = 0.0

        # Get robots current world orientation (convert to quaternion for transform)
        q = self.quaternion_from_euler(0, 0, self.theta)
        t.transform.rotation.x = q[0]
        t.transform.rotation.y = q[1]
        t.transform.rotation.z = q[2]
        t.transform.rotation.w = q[3]

        # Send the transformation
        self.world_tf_broadcaster.sendTransform(t)

    # converts euler (theta) values to a quaternion fromat for tf broadcast
    # (From ROS2 tutorials)
    def quaternion_from_euler(self, ai, aj, ak):
        ai /= 2.0
        aj /= 2.0
        ak /= 2.0
        ci = cos(ai)
        si = sin(ai)
        cj = cos(aj)
        sj = sin(aj)
        ck = cos(ak)
        sk = sin(ak)
        cc = ci * ck
        cs = ci * sk
        sc = si * ck
        ss = si * sk

        q = np.empty((4,))
        q[0] = cj * sc - sj * cs
        q[1] = cj * ss + sj * cc
        q[2] = cj * cs - sj * sc
        q[3] = cj * cc + sj * ss

        return q


    # load robot yaml description specified in given file
    def load_disc_robot(self, file_name):
        with open(file_name) as f:
            robot = yaml.safe_load(f)
        robot["urdf"] = self.disc_robot_urdf(robot)
        return robot

    # create the urdf used to generate 3D robot model
    def disc_robot_urdf(self, robot):
        radius = robot["body"]["radius"]
        height = robot["body"]["height"]

        return f"""<?xml version="1.0"?>
                    <robot name="disc">
                        <material name="light_blue">
                            <color rgba="0.5 0.5 1 1"/>
                        </material>
                        <material name="dark_blue">
                            <color rgba="0.1 0.1 1 1"/>
                        </material>
                        <material name="dark_red">
                            <color rgba="1 0.1 0.1 1"/>
                        </material>
                        <link name="base_link">
                            <visual>
                                <geometry>
                                    <cylinder length="{height}" radius="{radius}"/>
                                </geometry>
                                <material name="light_blue"/>
                            </visual>
                        </link>
                        <link name="heading_box">
                            <visual>
                                <geometry>
                                    <box size="{0.9*radius} {0.2*radius} {1.2*height}"/>
                                </geometry>
                                <material name="dark_blue"/>
                            </visual>
                        </link>
                        <link name="laser" />
                        <joint name="base_to_heading_box" type="fixed">
                            <parent link="base_link"/>
                            <child link="heading_box"/>
                            <origin xyz='{0.45*radius} 0.0 0.0'/>
                        </joint>
                        <joint name="base_to_laser" type="fixed">
                            <parent link="base_link"/>
                            <child link="laser"/>
                            <origin xyz="{0.5*radius} 0.0 0.0"/>
                        </joint>
                    </robot>
                    """

    # creates list of edges for every obstacle border
    def generate_edges(self):
        edges = []

        # helper variables
        x = 0.0
        y = 0.0
        length = self.world["resolution"]

        # loop through all obstacles in map
        r = len(self.str_map) - 1
        while r > -1:
            
            # for each obstacle (#) determine its edges
            for c in range(len(self.str_map[0])):
                if self.str_map[r][c] == "#":

                    # check for free spaces next to obstacles (indicating an edge)
                    if r > 0 and self.str_map[r-1][c] == ".": # up
                        edges.append(Edge(x, y+length, x+length, y+length, "up"))

                    if r < (len(self.str_map) - 1) and self.str_map[r+1][c] == ".": # down
                        edges.append(Edge(x, y, x+length, y, "down"))
                    
                    if c > 0 and self.str_map[r][c-1] == ".": # left
                        edges.append(Edge(x, y, x, y+length, "left"))
                    
                    if c < (len(self.str_map[0]) - 1) and self.str_map[r][c+1] == ".": # right
                        edges.append(Edge(x+length, y, x+length, y+length, "right"))
                
                x += length # move x to bottom left corner of next obstacle

            x=0.0 # reset x
            y+=length # move y to bottom left corner of next row of obstacles
            r-=1
        


        # concatenate edges
        # uses assumption that for any edge, an edge that extends it occurs later in edges list
        # (this is true based on order edges are added above)
        found = False
        i = 0

        # for each edge, add all edges connected to it, then move to next remaining edge
        while i < len(edges):
            edge = edges[i]
            found = False

            # search for edges to be added to current one
            for j in range(i+1, len(edges)):
                edge_concat = edges[j]

                # check if edges are connected (same direction and connection point)
                if edge.direction == edge_concat.direction:
                    if abs(edge.x2 - edge_concat.x1) < 0.02 and abs(edge.y2 - edge_concat.y1) < 0.02:

                        # if found connected edge add it to current one and remove it
                        edges.pop(j)
                        edges.pop(i)
                        edges.insert(i, Edge(edge.x1, edge.y1, edge_concat.x2, edge_concat.y2, edge.direction))
                        found = True
                        break

            # if no edge was found, concatenation for current edge is complete, move on
            if not found:
                i += 1
        
        
        return edges




def main(args=None):
    # Initialization
    rclpy.init(args=args)

    # Create control node
    sim = SimulationControl()

    # "spins" node to run simulation
    rclpy.spin(sim)

    # Destroy node
    sim.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
