import rclpy
from rclpy.node import Node
import yaml

from geometry_msgs.msg import Twist
from std_msgs.msg import Float64


# Class that will handle converting linear/angular velocities to left/right wheel velocities
class VelocityTransform(Node):
    # constructor
    def __init__(self):
        # Creates Node that will convert velocity types
        super().__init__("velocity_transform")

        filename = r"/home/btallin/humble/p4_ws/src/simulator/config/normal.robot"  # DETERMINES ROBOT DESCRIPTION USED
        # gathers and stores robot information
        self.robot = self.load_disc_robot(filename)

        self.l_dis = self.robot["wheels"]["distance"]  # distance between robot wheels

        # Declare subscription to '/cmd_vel' reads in velocity movement
        self.input = self.create_subscription(Twist, "/cmd_vel", self.user_inputs, 25)

        # Declare publisher '/vl' with Float type to publish left wheel velocity
        self.left_vel = self.create_publisher(Float64, "/vl", 15)

        # Declare publisher '/vr' with Float type to publish right wheel velocity
        self.right_vel = self.create_publisher(Float64, "/vr", 15)


    # reads user inputs and converts velocities from twist to direct wheel velocities
    def user_inputs(self, input_msg):
        # extract movement infor from twist message
        linear = input_msg.linear.x
        angular = input_msg.angular.z

        # calculate wheel velocities (translational not RPM)
        vl = Float64()
        vl.data = linear - (angular * self.l_dis / 2.0)
        vr = Float64()
        vr.data = linear + (angular * self.l_dis / 2.0)

        # publish wheel velocities
        self.left_vel.publish(vl)
        self.right_vel.publish(vr)

    

    # load robot yaml description specified in given file
    def load_disc_robot(self, file_name):
        with open(file_name) as f:
            robot = yaml.safe_load(f)
        robot["urdf"] = self.disc_robot_urdf(robot)
        return robot

    # create the urdf used to generate 3D robot model
    def disc_robot_urdf(self, robot):
        radius = robot["body"]["radius"]
        height = robot["body"]["height"]

        return f"""<?xml version="1.0"?>
                    <robot name="disc">
                        <material name="light_blue">
                            <color rgba="0.5 0.5 1 1"/>
                        </material>
                        <material name="dark_blue">
                            <color rgba="0.1 0.1 1 1"/>
                        </material>
                        <material name="dark_red">
                            <color rgba="1 0.1 0.1 1"/>
                        </material>
                        <link name="base_link">
                            <visual>
                                <geometry>
                                    <cylinder length="{height}" radius="{radius}"/>
                                </geometry>
                                <material name="light_blue"/>
                            </visual>
                        </link>
                        <link name="heading_box">
                            <visual>
                                <geometry>
                                    <box size="{0.9*radius} {0.2*radius} {1.2*height}"/>
                                </geometry>
                                <material name="dark_blue"/>
                            </visual>
                        </link>
                        <link name="laser" />
                        <joint name="base_to_heading_box" type="fixed">
                            <parent link="base_link"/>
                            <child link="heading_box"/>
                            <origin xyz='{0.45*radius} 0.0 0.0'/>
                        </joint>
                        <joint name="base_to_laser" type="fixed">
                            <parent link="base_link"/>
                            <child link="laser"/>
                            <origin xyz="{0.5*radius} 0.0 0.0"/>
                        </joint>
                    </robot>
                    """


def main(args=None):
    # Initialization
    rclpy.init(args=args)

    # Create node
    vel_transform = VelocityTransform()

    # "spins" node so it waits for callbacks
    rclpy.spin(vel_transform)

    # Destroy node
    vel_transform.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
