/*
	Original author of the starter code
    Tanzir Ahmed
    Department of Computer Science & Engineering
    Texas A&M University
    Date: 2/8/20
	
	Please include your Name, UIN, and the date below
	Name: Ethan Yu
	UIN: 728006055
	Date:
*/
// truncate -s 256K BIMDC/test.bin; time ./client -f test.bin -m 512; diff BIMDC/test.bin received/test.binme ./client -c t
#include "common.h"
#include "FIFORequestChannel.h"

using namespace std;

int main(int argc, char *argv[])
{
	int opt;
	int p = 1;
	double t = 0.0;
	int e = 1;
	int buffer = MAX_MESSAGE;

	bool pCheck = false,
		 tCheck = false,
		 fCheck = false,	 // file request
		 mCheck = false,	 // manual memory
		 cCheck = false;	 // check channel

	string fname = "";
	while ((opt = getopt(argc, argv, "p:t:e:f:m:c")) != -1)
	{
		switch (opt)
		{
		case 'p':
			p = atoi(optarg);
			pCheck = true;
			break;
		case 't':
			t = atof(optarg);
			tCheck = true;
			break;
		case 'e':
			e = atoi(optarg);
			break;
		case 'f':
			fname = optarg;
			fCheck = true;
			break;
		case 'm':
			buffer = atoi(optarg);
			mCheck = true;
			break;
		case 'c':
			cCheck = true;
			break;
		}
	}

	int pid = fork();
	if (pid < 0)
	{
		EXITONERROR("can not creat child for server");
	}

	if (pid == 0 && mCheck)
	{
		char *args[] = {(char *)"./server", (char *)"-m", (char *)to_string(buffer).c_str(), nullptr};
		if (execvp(args[0], args) < 0)
		{
			EXITONERROR("unable to launch the server");
		}
	}
	else if (pid == 0)
	{
		char *args[] = {(char *)"./server", nullptr};
		if (execvp(args[0], args) < 0)
		{
			EXITONERROR("unable to launch the server");
		}
	}

	FIFORequestChannel chan("control", FIFORequestChannel::CLIENT_SIDE);

	// example data point request
	char buf[MAX_MESSAGE]; // 256
	
	if (cCheck) // requests new channel
	{
		MESSAGE_TYPE c = NEWCHANNEL_MSG;
		chan.cwrite(&c, sizeof(MESSAGE_TYPE));
		memset(buf, 0, 256);
		chan.cread(buf, 256);
		FIFORequestChannel newchan(buf, FIFORequestChannel::CLIENT_SIDE);
		std::cout << "New Channel: " << buf << endl;
		
		if (tCheck && pCheck)
		{
			datamsg x(p, t, e);
			memcpy(buf, &x, sizeof(datamsg));
			newchan.cwrite(buf, sizeof(datamsg));
			double reply;
			newchan.cread(&reply, sizeof(double));
			std::cout << "For person " << p << ", at time " << t << ", the value of ecg " << e << " is " << reply << endl;
		}
		else if (pCheck)
		{
			double t1 = 0.0;
			int e1 = 1;
			int e2 = 2;
			double reply1;
			datamsg dm1(p, t1, e1);
			datamsg dm2(p, t1, e2);
			ofstream csvfile;
			string outputX1 = "received/x1.csv";
			csvfile.open(outputX1);
			for (int i = 0; i < 1000; i++)
			{
				newchan.cwrite(&dm1, sizeof(dm1));
				newchan.cread(&reply1, sizeof(double));
				csvfile << dm1.seconds << "," << reply1;

				newchan.cwrite(&dm2, sizeof(dm2));
				newchan.cread(&reply1, sizeof(double));
				csvfile << "," << reply1 << endl;

				dm1.seconds += 0.004;
				dm2.seconds += 0.004;
			}
			csvfile.close();
		}
		else if (fCheck)
		{
			filemsg fm(0, 0);
			int len = sizeof(filemsg) + (fname.size() + 1);
			char *buffer2 = new char[len];
			memcpy(buffer2, &fm, sizeof(filemsg));
			strcpy(buffer2 + sizeof(filemsg), fname.c_str());
			newchan.cwrite(buffer2, len); // I want the file length;
			__int64_t file_len;
			newchan.cread(&file_len, sizeof(__int64_t));

			filemsg *fmsg = (filemsg *)buffer2;
			string path = "received/" + fname;
			FILE *outputfile = fopen(path.c_str(), "w");
			fmsg->offset = 0;
			char *buffer3 = new char[buffer];

			int len_left = file_len;
			while (len_left > 0)
			{
				len_left < buffer ?	fmsg->length = len_left : fmsg->length = buffer;
				newchan.cwrite(buffer2, len);
				newchan.cread(buffer3, buffer);
				fwrite(buffer3, 1, fmsg->length, outputfile);
				fmsg->offset += fmsg->length;
				len_left -= fmsg->length;
			}
			fclose(outputfile);
			delete[] buffer2;
			delete[] buffer3;
		}

		MESSAGE_TYPE m = QUIT_MSG;
		newchan.cwrite(&m, sizeof(MESSAGE_TYPE)); 
	} 

	// no new channel
	else if (pCheck && tCheck)
	{
		datamsg x(p, t, e);
		memcpy(buf, &x, sizeof(datamsg));
		chan.cwrite(buf, sizeof(datamsg)); // question
		double reply;
		chan.cread(&reply, sizeof(double)); // answer
		cout << "For person " << p << ", at time " << t << ", the value of ecg " << e << " is " << reply << endl;
	}
	else if (pCheck)
	{
		double t1 = 0.0;
		int e1 = 1;
		int e2 = 2;
		double reply1;
		datamsg dm1(p, t1, e1);
		datamsg dm2(p, t1, e2);
		ofstream csvfile;
		string outputX1 = "received/x1.csv";
		csvfile.open(outputX1);
		for (int i = 0; i < 1000; i++)
		{
			chan.cwrite(&dm1, sizeof(dm1));
			chan.cread(&reply1, sizeof(double));
			// cout << "reading reply" << i << endl;
			csvfile << dm1.seconds << "," << reply1;

			chan.cwrite(&dm2, sizeof(dm2));
			chan.cread(&reply1, sizeof(double));
			csvfile << "," << reply1 << endl;

			dm1.seconds += 0.004;
			dm2.seconds += 0.004;
		}
		csvfile.close();
	}
	else if (fCheck)
	{
		filemsg fm(0, 0);
		int len = sizeof(filemsg) + (fname.size() + 1);
		char *buffer2 = new char[len];
		memcpy(buffer2, &fm, sizeof(filemsg));
		strcpy(buffer2 + sizeof(filemsg), fname.c_str());
		chan.cwrite(buffer2, len); // I want the file length;
		__int64_t file_len;
		chan.cread(&file_len, sizeof(__int64_t));

		filemsg *fmsg = (filemsg *)buffer2;
		string path = "received/" + fname;
		FILE *outputfile = fopen(path.c_str(), "w");
		fmsg->offset = 0;
		char *buffer3 = new char[buffer];

		int len_left = file_len;
		while (len_left > 0)
		{
			len_left < buffer ? fmsg->length = len_left : fmsg->length = buffer;
			chan.cwrite(buffer2, len);
			chan.cread(buffer3, buffer);
			fwrite(buffer3, 1, fmsg->length, outputfile);
			fmsg->offset += fmsg->length;
			len_left -= fmsg->length;
		}
		fclose(outputfile);
		delete[] buffer2;
		delete[] buffer3;
	}

	MESSAGE_TYPE m = QUIT_MSG;
	chan.cwrite(&m, sizeof(MESSAGE_TYPE));
	cout << "Client exited" << endl;
}
