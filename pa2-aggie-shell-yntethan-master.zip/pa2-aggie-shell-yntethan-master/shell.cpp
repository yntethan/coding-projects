#include <iostream>
#include <algorithm>
#include <string>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <time.h>
#include <fcntl.h>

#include <vector>
#include <string>
//#include <stack>
#include "Tokenizer.h"

// all the basic colours for a shell prompt
#define RED     "\033[1;31m"
#define GREEN	"\033[1;32m"
#define YELLOW  "\033[1;33m"
#define BLUE	"\033[1;34m"
#define WHITE	"\033[1;37m"
#define NC      "\033[0m"

using namespace std;

int main () {

    char saveDir1[256];
    char saveDir2[256];

    getcwd(saveDir1, 256);
    getcwd(saveDir2, 256);
    //stack<char[]> dirStack;

    int bgp1 = -1;
    int bgp2 = -1;

    time_t currentTime = time(0);
    char dateBuf[100];
    ctime_r(&currentTime, dateBuf);
    string str;

    for (size_t i = 0; i < sizeof(dateBuf); i++) {
        if (dateBuf[i]== '\n') {
            break;
        }
        str += dateBuf[i];
    }
    
    while (true) {
        // need date/time, username, and absolute path to current dir
        cout << YELLOW << str << " : " << saveDir2 << "$" << NC << " ";
        
        // get user inputted command
        string input;
        getline(cin, input);

        if (input == "") {
            continue;
        }

        if (input == "exit") {  // print exit message and break out of infinite loop
            cout << RED << "Now exiting shell..." << endl << "Goodbye" << NC << endl;
            break;
        }

        int cin_save = dup(0);
        int cout_save = dup(1); 

        // get tokenized commands from user input
        Tokenizer tknr(input);
        vector<Command*> cmds = tknr.commands;

        if (tknr.hasError()) {  // continue to next prompt if input had an error
            continue;
        }

        // // print out every command token-by-token on individual lines
        // // prints to cerr to avoid influencing autograder
        for (size_t i = 0; i < cmds.size(); i++) {
            //change directionary
            string path = saveDir2;
            if (cmds[i]->args[0] == "cd"){
                if (cmds[i]->args[1] == "-") {
                    path = string(saveDir1);
                    //if (saveDir1 ==) {}
                    //else {}
                    //dirStack.pop(); //somehow set top of stack to the current dir
                }
                // for (size_t j = 1; j < cmds.size(); j++) {
                //     if (cmds[i]->args[1] == "../") {
                //         //saveDir2 = dirStack.top();
                //         //disStack.pop();
                //         //saveDir1 = dirStack.top();
                //     }
                // }
                getcwd(saveDir1, 256);
                getcwd(saveDir2, 256);
                //dirStack.push(saveDir1);
                chdir((char*) path.c_str());

                continue;
            }
            
            
            int fd[2];
            pipe(fd);
            
            // fork to create child
            pid_t pid = fork();
            if (pid < 0) {  // error check
                perror("fork");
                exit(2);
            }
            if (pid == 0) {  // if child, exec to run command
                if (i < cmds.size()-1) {dup2(fd[1],1);}
                
                close(fd[0]);

                //if (cmds[i]->isBackground()) {close(fd[1]);}

                char* args[30];

                for (size_t j =0; j < cmds[i]->args.size(); j++) {
                    args[j] = const_cast<char*>(cmds[i]->args[j].c_str());
                }
                args[cmds[i]->args.size()] = nullptr;

                if (cmds[i]->hasInput()) {
                    int file = open(cmds[i] -> in_file.c_str(), O_RDONLY | O_CREAT, 0777);
                    dup2(file, 0);
                }

                if (cmds[i]->hasOutput()) {
                    int file = open(cmds[i] -> out_file.c_str(), O_RDONLY | O_CREAT, 0777);
                    dup2(file, 1);
                }

                if (execvp(args[0], args) < 0) {
                    perror("execvp");
                    exit(2);
                }

            } else { 
                dup2(fd[0], STDIN_FILENO);
                close(fd[1]);
                int status = 0;
                if (bgp2 > 0) {bgp2--;}
                if (cmds[i]->isBackground()) {
                    close(fd[0]);
                    bgp1 = pid;
                    bgp2 = 20;
                    break;
                }

                if (bgp1 > 0 && waitpid(bgp1, &status, WNOHANG) > 0) {bgp1 = bgp2 = -1;}

                if (status > 1) {exit(status);}

                waitpid(pid, &status, 0);
            }
        }
        dup2(cin_save, STDIN_FILENO);
        dup2(cout_save, STDOUT_FILENO);
        
    }
    waitpid(-1, NULL, 0);

}
