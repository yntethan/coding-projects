Instruction: https://docs.google.com/document/d/1aA-ieWpgfp6r_iODC2Y1gs_6UlWE8Pxu7L0Bld1_Vu0
