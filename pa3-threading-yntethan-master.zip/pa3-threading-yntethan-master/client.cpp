#include <fstream>
#include <iostream>
#include <thread>
#include <sys/time.h>
#include <sys/wait.h>

#include "BoundedBuffer.h"
#include "common.h"
#include "Histogram.h"
#include "HistogramCollection.h"
#include "FIFORequestChannel.h"

// ecgno to use for datamsgs
#define EGCNO 1

using namespace std;

void patient_thread_function (int patientNumber, int n, BoundedBuffer* patient_req_buffer) {

    double time1 = 0;
    datamsg d(patientNumber, time1, 1);

    for(int i = 0; i < n; i ++) {
        d.seconds = time1;
        patient_req_buffer->push((char *) &d, sizeof(datamsg));
        time1 += 0.004;
    }
}

void file_thread_function (string filename, int m, BoundedBuffer* file_req_buffer, FIFORequestChannel *chan) {
    // functionality of the file thread
    // file size
    

    filemsg fm(0,0);
    int len = sizeof(filemsg) + filename.size() + 1;
    char* buf2 = new char[len];
    memcpy(buf2, &fm, sizeof(filemsg));
    strcpy(buf2 + sizeof(filemsg), filename.c_str());
    chan->cwrite(buf2, len);
    long file_size;
    chan->cread(&file_size, sizeof(long));
   
    // open output file; allocate the memory fseek; close the file

    FILE *file = fopen(("./received/" + filename).c_str(), "w");
    fseek(file, file_size, SEEK_SET);// set the  length as file_size
    fclose(file);

    int off = 0;
    // while offset < file_size, produce a filemsg(offset, m)+filename and push to request_buffer
    while (off < file_size) {
        int buff_len = min((long)m, file_size-off);
        filemsg fmsg(off, buff_len);
        memcpy(buf2, &fmsg, sizeof(filemsg));
        file_req_buffer->push(buf2, len);
        off += fmsg.length;
    }
    delete[] buf2;
}

void worker_thread_function (int m, BoundedBuffer* req_buffer, BoundedBuffer* resp_buffer, FIFORequestChannel *chan, string f) {
    char* buf = new char[m];

    if (f != "") {        
        for(;;) {
            int file = open(("./received/" + f).c_str(), O_CREAT | O_WRONLY, S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
            int size = req_buffer->pop(buf, m);
            chan -> cwrite(buf, size);
            int len = sizeof(filemsg) + f.size()+1;
            if (((filemsg*)buf)->mtype == QUIT_MSG) {
                delete chan;
                break;
            }
            strcpy(buf + sizeof(filemsg), f.c_str());
            char* buf_ret = new char[m];
            chan -> cread(buf_ret, ((filemsg*)buf)->length);
            int seek = lseek(file, ((filemsg*)buf) -> offset, SEEK_SET);
            write (file, buf_ret, ((filemsg*)buf)->length);
            close(file);
            delete[] buf_ret;
        }
    } else {
        for(;;) {
            int size = req_buffer->pop(buf, m);
            chan -> cwrite(buf,size);
            if (((filemsg*)buf)->mtype == QUIT_MSG) {
                delete chan;
                break;
            }
            datamsg test = *((datamsg*)buf);
            
            double reply;
            chan -> cread(&reply, sizeof(double));
            std::pair<int, double> reponse(((datamsg*)buf)->person, reply);
            resp_buffer->push((char*)&reponse, sizeof(reponse));
        }
    }
    delete[] buf;
}  
//response buffer and hc in histogram
void histogram_thread_function (HistogramCollection* HC, BoundedBuffer* resp_buffer) {
    // functionality of the histogram threads
    // forever loop
    
    for (;;) {
        // pop response from response buffer
        char* respchar = new char[sizeof(pair<int, double>)];
        int size = resp_buffer->pop(respchar, sizeof(pair<int, double>));
        std::pair<int, double> resp = *((std::pair<int,double>*)respchar);
        delete[] respchar;
        // call HC::update(resp->p_no, resp->double)
        if (resp.first == -1) {
            break;
        }
        
        HC->update(resp.first, resp.second);
    }
}


int main (int argc, char* argv[]) {
    int n = 1000;	// default number of requests per "patient"
    int p = 10;		// number of patients [1,15]
    int w = 100;	// default number of worker threads
	int h = 20;		// default number of histogram threads
    int b = 20;		// default capacity of the request buffer (should be changed)
	int m = MAX_MESSAGE;	// default capacity of the message buffer
	string f = "";	// name of file to be transferred
    
    // read arguments
    int opt;
	while ((opt = getopt(argc, argv, "n:p:w:h:b:m:f:")) != -1) {
		switch (opt) {
			case 'n':
				n = atoi(optarg);
                break;
			case 'p':
				p = atoi(optarg);
                break;
			case 'w':
				w = atoi(optarg);
                break;
			case 'h':
				h = atoi(optarg);
				break;
			case 'b':
				b = atoi(optarg);
                break;
			case 'm':
				m = atoi(optarg);
                break;
			case 'f':
				f = optarg;
                break;
		}
	}
    
	// fork and exec the server
    int pid = fork();
    if (pid == 0) {
        execl("./server", "./server", "-m", (char*) to_string(m).c_str(), nullptr);
    }
    
	// initialize overhead (including the control channel)
	FIFORequestChannel* chan = new FIFORequestChannel("control", FIFORequestChannel::CLIENT_SIDE);
    BoundedBuffer request_buffer(b);
    BoundedBuffer response_buffer(b);
	HistogramCollection hc;

    // making histograms and adding to collection
    for (int i = 0; i < p; i++) {
        Histogram* h = new Histogram(10, -2.0, 2.0);
        hc.add(h);
    }
	
	// record start time
    struct timeval start, end;
    gettimeofday(&start, 0);

    /* create all threads here */
    vector<FIFORequestChannel*> request_channel;
    for (int i = 0; i < w; i++) {
        char* buffer = new char[256];
        MESSAGE_TYPE m2 = NEWCHANNEL_MSG;
        chan->cwrite(&m2, sizeof(MESSAGE_TYPE));
        chan->cread(buffer, 256);
        request_channel.push_back(new FIFORequestChannel(buffer, FIFORequestChannel::CLIENT_SIDE));

        delete[] buffer;
    }

    vector<thread> patient_thread(p);
    thread file_thread;
    if (f == "") { 
        for (int i = 0; i < p; i++) {
            patient_thread.at(i) = thread(patient_thread_function, i+1, n, &request_buffer);
        }
    } else {
        file_thread = thread(file_thread_function, f, m, &request_buffer, chan);
    }

    FIFORequestChannel* channel[w];
    vector<thread> worker_thread(w);
    for (int i = 0; i < w; i++) {
        worker_thread.at(i) = thread(worker_thread_function, m, &request_buffer, &response_buffer, request_channel.at(i), f);
    }

    vector<thread> histogram_thread(h);
    for (int i = 0; i < h; i++) {
        histogram_thread.at(i) = thread(histogram_thread_function, &hc, &response_buffer);
    }

    /* join all threads here */
    if (f == "") { 
        for (int i = 0; i < p; i++) {
            patient_thread.at(i).join();
        }
    } else {
        file_thread.join();
    } 
    
    for (int i = 0; i < w; i++) {
        MESSAGE_TYPE m2 = QUIT_MSG;
        request_buffer.push((char*)&m2, sizeof(MESSAGE_TYPE));
    }

    for (int i = 0; i < w; i++) {
        worker_thread.at(i).join();
    }

    for (int i = 0; i < h; i++) {
        pair<int, double> quit(-1, 0.0);
        response_buffer.push((char*)&quit, sizeof(quit));
    }
    for (int i = 0; i < h; i++) {
        histogram_thread.at(i).join();
    }
   
	// record end time
    gettimeofday(&end, 0);

    // print the results
	if (f == "") {
		hc.print();
	}
    int secs = ((1e6*end.tv_sec - 1e6*start.tv_sec) + (end.tv_usec - start.tv_usec)) / ((int) 1e6);
    int usecs = (int) ((1e6*end.tv_sec - 1e6*start.tv_sec) + (end.tv_usec - start.tv_usec)) % ((int) 1e6);
    cout << "Took " << secs << " seconds and " << usecs << " micro seconds" << endl;

	// quit and close control channel
    MESSAGE_TYPE q = QUIT_MSG;
    chan->cwrite ((char *) &q, sizeof (MESSAGE_TYPE));
    cout << "All Done!" << endl;
    delete chan;

	// wait for server to exit
	wait(nullptr);
}

