#include "TCPRequestChannel.h"

using namespace std;


TCPRequestChannel::TCPRequestChannel (const std::string _ip_address, const std::string _port_no) {
    struct sockaddr_in server_data; //= {AF_INET, (in_port_t) htons(stoi(_port_no)), {INADDR_ANY}, 0};
    memset(&server_data, 0, sizeof(server_data));
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    server_data.sin_family = AF_INET;
    server_data.sin_port = htons((unsigned short) strtoul(_port_no.c_str(), NULL, 0));
    if (sockfd == -1) {cerr << "socket: Could no create new socket" << endl;}
    if (_ip_address.empty()) {
        server_data.sin_addr.s_addr = INADDR_ANY;
        if (bind(sockfd, (struct sockaddr*) &server_data, sizeof(server_data)) != 0) {
            perror ("bind: Could not bind the server to sockfd ");
        }
        if (listen(sockfd, SOMAXCONN) != 0) {
            perror ("listen : Could not listen to sockfd ");
        }
    } else {
        if (inet_aton(_ip_address.c_str(), &server_data.sin_addr) == 0) {
            perror ("inet-aton: Could not convert IP Address to binary form");
        }
        if (connect(sockfd, (struct sockaddr*) &server_data, sizeof(server_data)) != 0) {
            perror ("connect: Could not connect to the server");
        }
    }
}

TCPRequestChannel::TCPRequestChannel (int _sockfd) {
    sockfd = _sockfd;
}

TCPRequestChannel::~TCPRequestChannel () {
    close(sockfd);
}

int TCPRequestChannel::accept_conn () {
    //struct sockaddr_storage mystor;
    //mystor.ss_family = AF_INET;
   
    //int newFD = accept(sockfd,(sockaddr*)&mystor, (socklen_t*) sizeof(mystor));
    int newFD = accept(sockfd, NULL, NULL);
    if (newFD <= -1) {
        cerr << "accept: Could not accecpt connection to socket " << sockfd << endl;}
    return newFD;
}

int TCPRequestChannel::cread (void* msgbuf, int msgsize) {
    return read (sockfd, msgbuf, msgsize);
}

int TCPRequestChannel::cwrite (void* msgbuf, int msgsize) {
    return write(sockfd, msgbuf, msgsize);
}
