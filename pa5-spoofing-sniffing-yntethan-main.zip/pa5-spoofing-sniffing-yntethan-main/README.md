Instructions: https://docs.google.com/document/d/117SnGrhtqgHxnLpU7FtSqgmhmAffeIJg1B3nKIjMiM4/edit?usp=sharing
